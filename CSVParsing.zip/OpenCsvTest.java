package com.mobiowin.windchim.test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.google.gson.Gson;
import com.mobiowin.windchim.bean.StudentProfileBean;
import com.opencsv.CSVReader;

public class OpenCsvTest {
	public static void main(String[] args) {

		String csvFile = "E:\\docs\\profile_records.csv";
		BufferedReader br = null;
		// String line = "";
		String cvsSplitBy = "";
		ArrayList<StudentProfileBean> profileList = null;
		List<String> recList = null;
		StudentProfileBean profileBean = null;
		CSVReader reader = null;

		try {

			reader = new CSVReader(new FileReader(csvFile));
			String[] line;
			br = new BufferedReader(new FileReader(csvFile));
			profileList = new ArrayList<StudentProfileBean>();
			while ((line = reader.readNext()) != null) {

				// String[] country =
				// line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
				recList = Arrays.asList(line);

				profileBean = new StudentProfileBean();
				profileBean.setId(recList.get(0));
				profileBean.setEnrollmentId(recList.get(1));
				profileBean.setBranchId(recList.get(2));
				profileBean.setClassName(recList.get(3));
				profileBean.setFatherNo(recList.get(4));
				profileBean.setFatherName(recList.get(5));
				profileBean.setMotherNo(recList.get(6));
				profileBean.setMotherName(recList.get(7));

				profileBean.setDoj(recList.get(8));

				profileBean.setDob(recList.get(9));

				profileBean.setPermanentAddress(recList.get(10).replaceAll(",", " "));
				profileBean.setTempAddress(recList.get(11));
				profileBean.setIsDayBoarding(recList.get(12));
				profileBean.setIsVan(recList.get(13));
				//profileBean.setCreatedBy(recList.get(14));
				//profileBean.setCreateDt(new Date());
				//profileBean.setModifiedBy(recList.get(16));
				//profileBean.setModifyDt(new Date());
				//profileBean.setDeleteFlag("F");

				profileList.add(profileBean);

			}

			System.out.println("Profile list is : " + profileList);

			String json = new Gson().toJson(profileList);
			System.out.println(json);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	private static Date convertDate(String date) {

		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date startDate = null;
		try {

			startDate = df.parse(date);
			String newDateString = df.format(startDate);
			System.out.println(newDateString);

			return startDate;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return startDate;
	}
}
