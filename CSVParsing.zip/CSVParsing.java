package com.mobiowin.windchim.test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.google.gson.Gson;
import com.mobiowin.windchim.bean.StudentProfileBean;

public class CSVParsing {
	public static void main(String[] args) {

		String csvFile = "E:\\docs\\profile_records.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = "";
		ArrayList<StudentProfileBean> profileList = null;
		List<String> recList = null;
		StudentProfileBean profileBean = null;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			profileList = new ArrayList<StudentProfileBean>();
			while ((line = br.readLine()) != null) {

				String[] country = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
				recList = Arrays.asList(country);

				profileBean = new StudentProfileBean();
				profileBean.setId(recList.get(0));
				profileBean.setEnrollmentId(recList.get(1));
				profileBean.setBranchId(recList.get(2));
				profileBean.setClassName(recList.get(3));
				profileBean.setFatherNo(recList.get(4));
				profileBean.setFatherName(recList.get(5));
				profileBean.setMotherNo(recList.get(6));
				profileBean.setMotherName(recList.get(7));

				/*if (null != recList.get(8) && recList.get(8).equals("")) {
					profileBean.setDoj(convertDate(recList.get(8)));
				}
				if (null != recList.get(9) && recList.get(9).equals("")) {
					profileBean.setDob(convertDate(recList.get(9)));
				}*/

				profileBean.setPermanentAddress(recList.get(10));
				profileBean.setTempAddress(recList.get(11));
				profileBean.setIsDayBoarding(recList.get(12));
				profileBean.setIsVan(recList.get(13));
				profileBean.setCreatedBy(recList.get(14));
				profileBean.setCreateDt(new Timestamp(new Date().getTime()));
				profileBean.setModifiedBy(recList.get(16));
				profileBean.setModifyDt(new Timestamp(new Date().getTime()));
				profileBean.setDeleteFlag("F");
				profileList.add(profileBean);

			}

			System.out.println("Profile list is : " + profileList);
			
			String json = new Gson().toJson(profileList );
			System.out.println(json);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	private static Date convertDate(String date) {

		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date startDate = null;
		try {
			
				startDate = df.parse(date);
				String newDateString = df.format(startDate);
				System.out.println(newDateString);
			
			return startDate;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return startDate;
	}
}
