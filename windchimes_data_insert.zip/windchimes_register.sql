/* CREATE TABLE */
CREATE TABLE table_name(
id DOUBLE,
enrollmentId VARCHAR(100),
className VARCHAR(100),
branchId DOUBLE,
fatherNo DOUBLE,
discription VARCHAR(100),
motherNo DOUBLE,
password VARCHAR(100),
createdBy VARCHAR(100),
modifiedBy VARCHAR(100),
delFlag VARCHAR(100)
);

/* INSERT QUERY NO: 1 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
1, 'WCPS320', 'TOD', 1, 7800008978, 'NULL', 7275772878, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 2 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
2, 'WCPS326', 'TOD', 1, 9415180073, 'NULL', 9415765778, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 3 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
3, 'WCPS331', 'TOD', 1, 9838588625, 'NULL', 9026222221, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 4 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
4, 'WCPS344', 'TOD', 1, 8009075600, 'NULL', 8853485124, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 5 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
5, 'WCPS345', 'TOD', 1, 8726127730, 'NULL', 8564909662, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 6 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
6, 'WCPS327', 'TOD', 1, 9760279786, 'NULL', 9456048786, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 7 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
7, 'WCPS348', 'TOD', 1, 9415608218, 'NULL', 9170604283, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 8 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
8, 'WCPS270', 'PG', 1, 8795253777, 'NULL', 9792520917, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 9 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
9, 'WCPS277', 'PG', 1, 9565670721, 'NULL', 8765740279, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 10 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
10, 'WCPS306', 'PG', 1, 9792972333, 'NULL', 9807070735, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 11 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
11, 'WCPS318', 'PG', 1, 9450649006, 'NULL', 7275705784, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 12 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
12, 'WCPS319', 'PG', 1, 7275772878, 'NULL', 7275772878, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 13 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
13, 'WCPS321', 'PG', 1, 9451948972, 'NULL', 9918204309, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 14 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
14, 'WCPS322', 'PG', 1, 8005180676, 'NULL', 8573029483, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 15 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
15, 'WCPS324', 'PG', 1, 9450025395, 'NULL', 9839888839, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 16 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
16, 'WCPS329', 'PG', 1, 9792100226, 'NULL', 9005348635, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 17 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
17, 'WCPS330', 'PG', 1, 9936199364, 'NULL', 8960817140, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 18 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
18, 'WCPS332', 'PG', 1, 9935132555, 'NULL', 9935164222, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 19 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
19, 'WCPS333', 'PG', 1, 9450217273, 'NULL', 9450619909, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 20 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
20, 'WCPS334', 'PG', 1, 8601901111, 'NULL', 9648270357, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 21 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
21, 'WCPS338', 'PG', 1, 9838244417, 'NULL', 9044623633, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 22 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
22, 'WCPS340', 'PG', 1, 0, 'NULL', 8876231056, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 23 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
23, 'WCPS341', 'PG', 1, 7376307391, 'NULL', 9696116966, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 24 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
24, 'WCPS342', 'PG', 1, 9415548660, 'NULL', 9450703831, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 25 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
25, 'WCPS316', 'PG', 1, 9450769806, 'NULL', 8931824029, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 26 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
26, 'WCPS337', 'PG', 1, 7080806422, 'NULL', 8853164066, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 27 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
27, 'WCPS349', 'PG', 1, 9335492044, 'NULL', 8004709522, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 28 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
28, 'WCPS350', 'PG', 1, 9236805907, 'NULL', 7607855805, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 29 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
29, 'WCPS355', 'PG', 1, 9161711820, 'NULL', 7318257174, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 30 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
30, 'WCPS261', 'PN', 1, 7617870628, 'NULL', 9889970828, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 31 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
31, 'WCPS282', 'PN', 1, 8004971257, 'NULL', 9005569423, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 32 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
32, 'WCPS299', 'PN', 1, 8853265807, 'NULL', 9936420402, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 33 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
33, 'WCPS305', 'PN', 1, 9654890640, 'NULL', 8874266322, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 34 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
34, 'WCPS280', 'PN', 1, 0, 'NULL', 9450790512, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 35 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
35, 'WCPS285', 'PN', 1, 9839315780, 'NULL', 8601988892, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 36 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
36, 'WCPS311', 'PN', 1, 9839649281, 'NULL', 0, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 37 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
37, 'WCPS315', 'PN', 1, 7408432762, 'NULL', 7408432763, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 38 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
38, 'WCPS317', 'PN', 1, 9415088669, 'NULL', 9454888974, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 39 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
39, 'WCPS276', 'PN', 1, 9455710833, 'NULL', 7379753184, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 40 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
40, 'WCPS323', 'PN', 1, 0, 'NULL', 9792199341, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 41 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
41, 'WCPS267', 'PN', 1, 9839823512, 'NULL', 9452536818, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 42 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
42, 'WCPS253', 'PN', 1, 7071605054, 'NULL', 9565573731, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 43 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
43, 'WCPS290', 'PN', 1, 9125812099, 'NULL', 9125812049, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 44 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
44, 'WCPS301', 'PN', 1, 9305208613, 'NULL', 8687823700, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 45 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
45, 'WCPS335', 'PN', 1, 9648404040, 'NULL', 9648984040, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 46 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
46, 'WCPS346', 'PN', 1, 9005526786, 'NULL', 9935513400, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 47 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
47, 'WCPS347', 'PN', 1, 7897131530, 'NULL', 7054528276, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 48 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
48, 'WCPS279', 'PN', 1, 7786967781, 'NULL', 0, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 49 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
49, 'WCPS351', 'PN', 1, 9410003313, 'NULL', 9410000513, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 50 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
50, 'WCPS353', 'PN', 1, 9267355311, 'NULL', 8400552255, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 51 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
51, 'WCPS220', 'NUR', 1, 9634032834, 'NULL', 9454287608, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 52 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
52, 'WCPS266', 'NUR', 1, 9919356204, 'NULL', 7068882318, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 53 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
53, 'WCPS268', 'NUR', 1, 7704067828, 'NULL', 9415467828, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 54 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
54, 'WCPS248', 'NUR', 1, 9918226600, 'NULL', 9918442200, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 55 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
55, 'WCPS242', 'NUR', 1, 9454667199, 'NULL', 8382851699, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 56 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
56, 'WCPS295', 'NUR', 1, 9838383780, 'NULL', 8004743539, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 57 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
57, 'WCPS255', 'NUR', 1, 9792000522, 'NULL', 9919100522, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 58 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
58, 'WCPS246', 'NUR', 1, 9415470330, 'NULL', 9598737034, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 59 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
59, 'WCPS292', 'NUR', 1, 9450400009, 'NULL', 9721500009, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 60 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
60, 'WCPS250', 'NUR', 1, 8090555135, 'NULL', 8090408363, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 61 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
61, 'WCPS251', 'NUR', 1, 9454659413, 'NULL', 9935480726, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 62 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
62, 'WCPS254', 'NUR', 1, 9415003216, 'NULL', 9452971919, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 63 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
63, 'WCPS281', 'NUR', 1, 9335226968, 'NULL', 9696028560, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 64 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
64, 'WCPS298', 'NUR', 1, 8874509636, 'NULL', 9889436360, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 65 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
65, 'WCPS328', 'NUR', 1, 9415596782, 'NULL', 7376124893, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 66 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
66, 'WCPS352', 'NUR', 1, 7080529341, 'NULL', 8417023083, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 67 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
67, 'WCPS354', 'NUR', 1, 9919881010, 'NULL', 8960217206, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 68 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
68, 'WCPS116', 'KG', 1, 9415892381, 'NULL', 9415892379, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 69 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
69, 'WCPS186', 'KG', 1, 7800007474, 'NULL', 9415104388, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 70 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
70, 'WCPS187', 'KG', 1, 9936148700, 'NULL', 7505655106, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 71 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
71, 'WCPS131', 'KG', 1, 9415424451, 'NULL', 8004531547, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 72 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
72, 'WCPS203', 'KG', 1, 8604987576, 'NULL', 7376333000, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 73 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
73, 'WCPS214', 'KG', 1, 9918000165, 'NULL', 9415465090, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

/* INSERT QUERY NO: 74 */
INSERT INTO table_name(id, enrollmentId, className, branchId, fatherNo, discription, motherNo, password, createdBy, modifiedBy, delFlag)
VALUES
(
74, 'WCPS102', 'KG', 1, 9838653777, 'NULL', 9984653777, 'NULL', 'SYSTEM', 'SYSTEM', 'F'
);

