/* CREATE TABLE */
CREATE TABLE table_name(
id DOUBLE,
enrollmentId VARCHAR(100),
branchId DOUBLE,
className VARCHAR(100),
fatherNo DOUBLE,
fatherName VARCHAR(100),
motherNo DOUBLE,
motherName VARCHAR(100),
doj VARCHAR(100),
dob VARCHAR(100),
permanentAddress VARCHAR(100),
tempAddress VARCHAR(100),
isDayBoarding VARCHAR(100),
isVan VARCHAR(100)
);

/* INSERT QUERY NO: 1 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
1, 'WCPS320', 1, 'TOD', 7800008978, 'Mhmd.Shamsh Reza', 7275772878, 'Shamsm Reza', '05/02/16', '12/09/13', 'B1/57 Sec-G Jankipuram  LKO', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 2 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
2, 'WCPS326', 1, 'TOD', 9415180073, 'Fakhruddin Ali', 9415765778, 'Samreen Margoob', '30/03/2016', '19/01/2014', 'A-26  Alisha Nagar  Sec- I  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 3 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
3, 'WCPS331', 1, 'TOD', 9838588625, 'Rajeev Kumar Mishra', 9026222221, 'Janhvi Mohan', '08/04/16', '19/01/2014', '12/7  Sahara State', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 4 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
4, 'WCPS344', 1, 'TOD', 8009075600, 'Amit Kumar Singh', 8853485124, 'Devyani Dayal', '04/08/16', '15/06/2014', 'I-98 647-B Jankipuram Garden  Near Apex Trauma Centre  lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 5 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
5, 'WCPS345', 1, 'TOD', 8726127730, 'Pradeep Kumar C.G', 8564909662, 'Banu K.P', '04/07/16', '24/11/2014', 'C-34  Eldeco City  IIM Road  lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 6 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
6, 'WCPS327', 1, 'TOD', 9760279786, 'Aasif Ahmed', 9456048786, '', '30/03/2016', '20/11/2013', 'A-26  Alisha Nagar  Sec-I Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 7 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
7, 'WCPS348', 1, 'TOD', 9415608218, 'Manoj Kumar', 9170604283, 'Rekha', '30/6/2016', '10/02/14', '647B/B31  JankiGarden Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 8 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
8, 'WCPS270', 1, 'PG', 8795253777, 'Vincent Anthony', 9792520917, 'Neeta Anthony', '21/04/2015', '13/11/2013', 'Flat No.802 S-2 Eldeco Eden Park Apartments Kursi Road lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 9 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
9, 'WCPS277', 1, 'PG', 9565670721, 'Narendra Kumar', 8765740279, 'Meenu Baudh', '26/06/2015', '25/05/2013', 'DS-2/233 SEC -C Jankipuram Kursi Road LKO', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 10 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
10, 'WCPS306', 1, 'PG', 9792972333, 'Rohit kr. Sirsat', 9807070735, 'Suvidhi Verma', '07/08/15', '14/03/2013', 'C2/323 Sec -F  Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 11 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
11, 'WCPS318', 1, 'PG', 9450649006, 'Ravi Shankar Jaiswal', 7275705784, 'Shweta Jaiswal', '25/01/2016', '25/04/2013', 'H.no.643 M/846 Aziz Nagar Colony Madiyaon Thana Sitapur Road', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 12 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
12, 'WCPS319', 1, 'PG', 7275772878, 'Mhmd.Shamsh Reza', 7275772878, 'Shamsm Reza', '05/02/16', '26/06/2013', 'B1/57 Sec-G Jankipuram  LKO', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 13 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
13, 'WCPS321', 1, 'PG', 9451948972, 'Amritansh', 9918204309, 'Tinu  Katiya', '19/02/2016', '18/07/2013', 'D-2-494  Sec-F  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 14 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
14, 'WCPS322', 1, 'PG', 8005180676, 'Nikhil Kumar Singh', 8573029483, 'Jyoti Singh', '29/02/2016', '21/12/2013', 'E-2/374  Sec-F  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 15 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
15, 'WCPS324', 1, 'PG', 9450025395, 'Ishwar Chandra Chaurasia', 9839888839, 'Seema Chaurasia', '14/03/2016', '08/02/13', '35 A Adil Nagar Kursi Road', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 16 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
16, 'WCPS329', 1, 'PG', 9792100226, 'Arun Singh', 9005348635, 'Deepmala Verma', '06/04/16', '18/05/2013', '645-A/426  Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 17 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
17, 'WCPS330', 1, 'PG', 9936199364, 'Anku Chopra', 8960817140, 'Priyanka Chopra', '07/04/16', '08/02/13', 'H.No. 208  Keshau Nagar Colony', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 18 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
18, 'WCPS332', 1, 'PG', 9935132555, 'Vijay Pratap', 9935164222, 'Alka Devi Verma', '12/04/16', '04/02/14', '30-B  Alisha Nagar  Sec -I Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 19 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
19, 'WCPS333', 1, 'PG', 9450217273, 'Udit Narayan Singh', 9450619909, 'Neetu Singh', '13/04/2016', '12/06/13', 'H.No- 647 B/337A  Jankipuram Garden LKO', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 20 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
20, 'WCPS334', 1, 'PG', 8601901111, 'Arvind Kumar Singh', 9648270357, 'Vibha Singh', '13/04/2016', '19/04/2013', 'Deort Ruichara P.O Arjunpur Bakshi Ka Talab', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 21 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
21, 'WCPS338', 1, 'PG', 9838244417, 'Praveen Singh Rathore', 9044623633, 'Seema Singh', '20/04/2016', '05/01/14', '647B/A33   Jankipuram   Lucknow', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 22 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
22, 'WCPS340', 1, 'PG', 0, '', 8876231056, 'Dhanshree Basumatari', '04/06/16', '12/10/11', '7/502  Sahara Grace  Malhar Deluxe  lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 23 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
23, 'WCPS341', 1, 'PG', 7376307391, 'Narendra Mishra', 9696116966, 'Namita Mishra', '30/06/2016', '18/12/2013', 'A-33 Kalyanpur Shivpuri  lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 24 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
24, 'WCPS342', 1, 'PG', 9415548660, 'Shikar Srivastava', 9450703831, 'Pallavi Srivastava', '02/07/16', '25/08/2013', 'M-2/65 Sec-I  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 25 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
25, 'WCPS316', 1, 'PG', 9450769806, 'Manoj Kumar Shukla', 8931824029, 'Richa Shukla', 'NULL', 'NULL', 'SS-56 55 Sec-D  Near Ring Road Jankipuram LKO', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 26 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
26, 'WCPS337', 1, 'PG', 7080806422, 'Atif Hussain', 8853164066, 'Dr. Nausheen Atif', '', '', '302  Mumtaz Apartment  Eden Clave Kursi Road  LKO.', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 27 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
27, 'WCPS349', 1, 'PG', 9335492044, 'Rajesh Kumar Singh', 8004709522, 'Arti Singh', '15/07/2016', '28/06/2013', '2/227  Sector -H  Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 28 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
28, 'WCPS350', 1, 'PG', 9236805907, 'Manas Nirmal', 7607855805, 'Alka Kothari', '25/07/2016', '06/03/14', 'A-1/34  sec-I  Near capital convent School  Prabhat Chauraha  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 29 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
29, 'WCPS355', 1, 'PG', 9161711820, 'Vinamra Sharma', 7318257174, 'Shikha Shrama', '', '17/01/2014', 'HI -191 Sec- I Jankipuram near prabhat chaura lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 30 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
30, 'WCPS261', 1, 'PN', 7617870628, 'Satish Kumar', 9889970828, 'Vandana Pandey', '04/06/15', '19/7/2012', 'Plot.no.7 Phool Bagh Enclave Opp.Gudumba Thana Kursi Road lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 31 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
31, 'WCPS282', 1, 'PN', 8004971257, 'Ajay Kumar Verma', 9005569423, 'Neelam Soni', '06/07/15', '13/03/2013', 'D-1/199 Sec- F Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 32 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
32, 'WCPS299', 1, 'PN', 8853265807, 'Dr. Mohammad Kalim Ahmed Khan', 9936420402, 'Afsana', '22/07/2015', '17/07/2013', 'Flat No. 303 Mumtaz Apartment  Eden Enclave Kursi Road lko.', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 33 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
33, 'WCPS305', 1, 'PN', 9654890640, 'Prabhat Kumar', 8874266322, 'Archana Sharma', '05/08/15', '03/01/13', '`3/101 Malhar Sahara Grace Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 34 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
34, 'WCPS280', 1, 'PN', 0, 'Pawan Chandel', 9450790512, 'Himani Singh', '01/07/15', '25/02/2013', 'Sec -I Jankipuram Behind Capital Convent School Prabhat Chauraha lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 35 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
35, 'WCPS285', 1, 'PN', 9839315780, 'Anand Khare', 8601988892, 'Shweta Prakash', '08/07/15', '23/04/2013', '7/403 Sahara Grace Malhar Deluxe  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 36 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
36, 'WCPS311', 1, 'PN', 9839649281, 'Hemant Kumar Singh', 0, 'Sudha Singh', '03/11/15', '07/04/13', 'C-1/405 Sector -G  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 37 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
37, 'WCPS315', 1, 'PN', 7408432762, 'Pankaj Srivastava', 7408432763, 'Reena Srivastava', '14/12/2015', '17/10/2012', 'D-1/159  Sector-F  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 38 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
38, 'WCPS317', 1, 'PN', 9415088669, 'Kavindra Jain', 9454888974, 'Anubha Jain', '2018-01-16', '12/02/13', 'C-2/174  Sec -F Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 39 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
39, 'WCPS276', 1, 'PN', 9455710833, 'Rahul Tiwari', 7379753184, 'Lalita Tiwari', '08/06/15', '08/01/13', 'sec-8/417  Indra Nagar', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 40 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
40, 'WCPS323', 1, 'PN', 0, 'Jitendra Tomar', 9792199341, 'Pooja Tomar', '12/03/16', '05/05/13', 'Villa no.-426  Eldeco City Near IIM', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 41 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
41, 'WCPS267', 1, 'PN', 9839823512, 'Mohd.Zafar Hamid', 9452536818, 'Dr.Shahla Parveen', '17/04/2015', '29/03/2013', '29 Jankipuram Garden Near Capital Public School Jankipuram Sec-J lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 42 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
42, 'WCPS253', 1, 'PN', 7071605054, 'Mr Praveen rastogi', 9565573731, 'Mrs Diksha', '03/12/15', '25/9/2012', 'Village and Post Mondiyon Jakipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 43 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
43, 'WCPS290', 1, 'PN', 9125812099, 'Ashish Kumar', 9125812049, 'Kavita Das Gautam', '07/07/15', '04/09/12', 'C-2/252 Sec-F Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 44 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
44, 'WCPS301', 1, 'PN', 9305208613, 'DR.D.N Mishra', 8687823700, 'Amrita Mishra', '27/07/2015', '', '1 Prem Nagar near Genetis club  Behind Blue cross Hospital Kursi road lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 45 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
45, 'WCPS335', 1, 'PN', 9648404040, 'Akshay Singh', 9648984040, 'Sapna Singh', '2016-04-16', '24/02/2013', '401 Tower-S2 Eldeco Eden Park Estate Kursi Road', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 46 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
46, 'WCPS346', 1, 'PN', 9005526786, 'Ratnakar Singh', 9935513400, 'Savita Singh', '08/07/16', '21/12/2012', 'E-2/436  Sec-F  Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 47 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
47, 'WCPS347', 1, 'PN', 7897131530, 'Dr. Arun Kumar Maurya', 7054528276, 'Arti Maurya', '11/07/16', '15/11/2012', '1/18  Sec- J  Jankipuram Extention lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 48 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
48, 'WCPS279', 1, 'PN', 7786967781, 'Prakash Kumar Mishra', 0, 'Dr.Supriya Bharti', '30/06/2015', '20/02/2013', 'C-2/204 Sec-F Jankipuram behind Icon Hospital LKO', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 49 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
49, 'WCPS351', 1, 'PN', 9410003313, 'Uday Mani Patel', 9410000513, 'Pooja Patel', '27/7/2016', '02/11/12', '16  Phool Bagh Enclave near Gudamba Police Station lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 50 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
50, 'WCPS353', 1, 'PN', 9267355311, 'Manoj Kumar', 8400552255, 'Upma', '09/08/16', '20/09/2013', 'Type- 2/18  Sec -D  Sachivalya colony Aliganj  lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 51 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
51, 'WCPS220', 1, 'NUR', 9634032834, 'Mr Atul Shukla', 9454287608, 'Mrs Preeti Shukla', '07/12/14', '23/12/2011', 'Pawan kutir D-1/121 Sec- F jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 52 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
52, 'WCPS266', 1, 'NUR', 9919356204, 'Aneesh  Sachan', 7068882318, 'Minakshi Sachan', '13/04/2015', '31/12/2011', 'D2/553 Sec-F  Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 53 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
53, 'WCPS268', 1, 'NUR', 7704067828, 'Ankit Dalela', 9415467828, 'Parul', '18/14/2015', '06/02/12', '2/627 Vikas Nagar Lucknow', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 54 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
54, 'WCPS248', 1, 'NUR', 9918226600, 'Mr. Aman Bond', 9918442200, 'Mrs. Sonia Oliver', '02/27/15', '25/8/2011', '10/41 Bahar-A Sahara State Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 55 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
55, 'WCPS242', 1, 'NUR', 9454667199, 'Mr Dilip Kumar', 8382851699, 'Mrs Sarita yadav', '01/12/15', '27/10/2011', '3/906 Sector-H jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 56 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
56, 'WCPS295', 1, 'NUR', 9838383780, 'Meraj Ahmed Khan', 8004743539, 'Shabana khan', '14/07/2015', '08/08/12', 'Flat no.-404 Eden Enclave Mumtaz Apartment Kursi Road lko.', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 57 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
57, 'WCPS255', 1, 'NUR', 9792000522, 'Mr Bhupendra Singh', 9919100522, 'Mrs Reeta singh', '18/3/2015', '08/18/12', 'A-37 Shivpuri near Metro hospital Kalyanpur Lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 58 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
58, 'WCPS246', 1, 'NUR', 9415470330, 'Sheel kumar mishra', 9598737034, 'monika mishra', '01/19/15', '25/03/2012', '4/73 sc-4 jankipuram vistaar lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 59 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
59, 'WCPS292', 1, 'NUR', 9450400009, 'Vinay Kumar Singh', 9721500009, 'Nidhi Singh', '09/07/15', '26/03/2013', '10/101 Malhar Delux Sahara Grace', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 60 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
60, 'WCPS250', 1, 'NUR', 8090555135, 'Mr Dharmendra Soni', 8090408363, 'Mrs Jodhi rastogi', '03/02/15', '20/9/2012', 'H.No.21 Eldeco Town IIM road in front of bal bharti school', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 61 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
61, 'WCPS251', 1, 'NUR', 9454659413, 'MrVivek Kr.Verma', 9935480726, 'Mrs Ankita Verma', '03/03/15', '27/8/2012', 'D-1/46 sector -F jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 62 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
62, 'WCPS254', 1, 'NUR', 9415003216, 'Mr Amit Kumar', 9452971919, 'Adwita', '03/14/15', '02/05/12', '7/201 Deepak Deluxe sahara grace jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 63 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
63, 'WCPS281', 1, 'NUR', 9335226968, 'Abhay Kumar Suman', 9696028560, 'Anupama Singha', '04/07/15', '12/06/12', 'Anupam Villa 140 Chudiyapurwa Sec -G  Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 64 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
64, 'WCPS298', 1, 'NUR', 8874509636, 'Dr. R.S. Rajpoot', 9889436360, 'Dr. Stuti Tondon', '22/7/2015', '27/10/2012', '1/501 Malhar Deluxe Sahara Grace Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 65 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
65, 'WCPS328', 1, 'NUR', 9415596782, 'Ashish Bhadauria', 7376124893, 'Jyoti', '06/04/16', '03/11/11', 'M-11/33  Sec-I  Jankipurram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 66 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
66, 'WCPS352', 1, 'NUR', 7080529341, 'Rajesh Kumar Verma', 8417023083, 'Kabita Devi', '01/08/16', '29/6/2012', 'H.N-616/52A  Khadri  Sitapur Road  lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 67 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
67, 'WCPS354', 1, 'NUR', 9919881010, 'Amar Raghuvanshi', 896021720, 'Beenu Raghuvanshi', '12/08/16', '21/11/2012', '12/15 Yaman Sahara States Jankipuram lko', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 68 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
68, 'WCPS116', 1, 'KG', 9415892381, 'Mr Ajay Kr Singh', 9415892379, 'Mrs Madhurima', '07/31/12', '24/11/2010', '645-A/572 Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 69 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
69, 'WCPS186', 1, 'KG', 7800007474, 'Mr Rochak tondon', 9415104388, 'Mrs Shipra Tondon', '12/17/13', '23/9/2011', 'B-1/98-A Sec-G Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 70 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
70, 'WCPS187', 1, 'KG', 9936148700, 'Mr Sunil Kr Gupta', 7505655106, 'Mrs Raksha Gupta', '01/27/14', '18/12/2010', '4/345 Sec-H Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 71 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
71, 'WCPS131', 1, 'KG', 9415424451, 'Santosh Kumar Yadav', 8004531547, 'Archana Yadav', '10/08/15', '26/02/2011', '252  Keshav Nagar  Near Surbhi Public School  Near sitaour Raod  Lucknow', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 72 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
72, 'WCPS203', 1, 'KG', 8604987576, 'Mrs Ashish Tripathi', 7376333000, 'Mrs Anjali Tripathi', '03/26/14', '10/09/11', 'B-1/76 Sec-G jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 73 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
73, 'WCPS214', 1, 'KG', 9918000165, 'Mr Arvind Kr Nanda', 9415465090, 'Mrs Jyoti Saroj', '07/05/14', '28/9/2011', 'E-2/369 Sec-F Jankipuram', 'NULL', 'N', 'N'
);

/* INSERT QUERY NO: 74 */
INSERT INTO table_name(id, enrollmentId, branchId, className, fatherNo, fatherName, motherNo, motherName, doj, dob, permanentAddress, tempAddress, isDayBoarding, isVan)
VALUES
(
74, 'WCPS102', 1, 'KG', 9838653777, 'Ravindra Kumarv Yadav', 9984653777, 'Namita Yadav', '07/07/14', '2022-09-09', '22  Rahul Bhawan  Paharpur Chauraha  Kursi Road', 'NULL', 'N', 'N'
);

